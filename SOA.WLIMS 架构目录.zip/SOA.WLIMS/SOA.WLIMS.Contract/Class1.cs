﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SOA.WLIMS.Contract
{
    public class Class1
    {
    }
}
