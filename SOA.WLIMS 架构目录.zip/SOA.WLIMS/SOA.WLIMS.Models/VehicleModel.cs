﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SOA.WLIMS.Models
{
    public class VehicleModel
    {
        #region 基元属性
        public global::System.Int64 ID
        { get; set; }
        public global::System.String Name
        { get; set; }
        public global::System.String LicensePlateNumber
        { get; set; }
        public global::System.String Status
        { get; set; }

        #endregion

    }
}
