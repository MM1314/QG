﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using WX.Model.ApiResponses;

namespace WX.Model.ApiRequests
{
    public class MerchantOrderSetdeliveryRequest : ApiRequest<DefaultResponse>
    {
        [JsonProperty("order_id")]
        public string OrderID { get; set; }

        [JsonProperty("delivery_company")]
        public string DeliveryCompany { get; set; }

        [JsonProperty("delivery_track_no")]
        public string DeliveryTrackNo { get; set; }

        internal override string Method
        {
            get { return POSTMETHOD; }
        }

        protected override string UrlFormat
        {
            get { return "https://api.weixin.qq.com/merchant/order/setdelivery?access_token={0}"; }
        }

        internal override string GetUrl()
        {
            return String.Format(UrlFormat, AccessToken);
        }

        protected override bool NeedToken
        {
            get { return true; }
        }

        public override string GetPostContent()
        {
            return JsonConvert.SerializeObject(this);
        }
    }
}
