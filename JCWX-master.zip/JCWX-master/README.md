微信快速开发框架（WXPP QuickFramework）已更新至V4.0版本上线

您可以用来做什么？
您可以使用此框架快速开发微信公众平台，目前V3.0已经支持高级接口的开发。

使用教程可以参考我的博客：http://inday.cnblogs.com

如果在使用中有任何问题，可以Email给我：james#taogame.com

---------------------------------------------------------------------------
更新日期：2015-1-26
更新内容：
1、增加了对客服管理的支持
2、增加了获取微信服务器端ip列表
3、增加了短链接推广支持
4、增加了模板消息的支持
5、修正了部分bug

暂时没有更新博客，等有时间再写，使用方法可参以下教程

---------------------------------------------------------------------------

快速开发系列教程：<br />
一、[对微信公众平台开发的消息处理](http://www.cnblogs.com/inday/p/weixin-dev-msg-Question.html)<br />
二、[快速开发微信公众平台框架---简介](http://www.cnblogs.com/inday/p/weixin-public-platform.html)<br />
三、[建立微信公众平台测试账号](http://www.cnblogs.com/inday/p/weixin-public-platform-test-account.html)<br />
四、[体验微信公众平台快速开发框架](http://www.cnblogs.com/inday/p/wx-publicform-quick-framework-webdemo.html)<br />
五、[利用快速开发框架，快速搭建微信浏览博客园首页文章](http://www.cnblogs.com/inday/p/weixin-publicf-platform-cnblogs.html)<br />
六、[微信快速开发框架（WXPP QuickFramework）V2.0版本上线--源码已更新至github](http://www.cnblogs.com/inday/p/wxpp-quick-framework-v-2.html)<br />
七、[微信快速开发框架（七）--发送客服信息，版本更新至V2.2](http://www.cnblogs.com/inday/p/weixin-public-platform-quick-framework-v-2-2.html)<br />
八、[微信快速开发框架V2.3--增加语音识别及网页获取用户信息](http://www.cnblogs.com/inday/p/wechat-public-platform-v2-3.html)

----------------------------------------------------------------------------
如果您觉得好，也可以通过以下二维码捐助我：
![image](https://mobilecodec.alipay.com/show.htm?code=apkk7iarj6b5z7ik7f&picSize=L)
